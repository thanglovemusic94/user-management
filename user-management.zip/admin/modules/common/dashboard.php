<?php if (!defined('IN_SITE')) die('The request not found'); ?>
<?php include_once('./admin/widgets/header.php'); ?>
<h1>Chào mừng bạn đến với trang quản trị admin [Author: freetuts.net]!</h1>
<?php include_once('./admin/widgets/footer.php'); ?>