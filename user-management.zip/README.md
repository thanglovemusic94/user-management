# user-management

use php mvc basic not oop 


https://files.000webhostapp.com/

user:
vanjose

password
vanjose123456


xem cai nay de tai zip len
https://www.youtube.com/watch?v=NBvg6JJtzDo

https://github.com/ndeet/unzipper



-database
Tên databases: user_management
nguoi dung database: vanthang
db_user: id20568307_vanthang
db_name: id20568307_user_management
password: SD(wOM2wxt^&@1(c